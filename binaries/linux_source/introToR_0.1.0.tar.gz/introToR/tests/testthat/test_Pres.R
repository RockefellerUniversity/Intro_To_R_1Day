library(introToR)
context("Presentations")

test_that("Check R code in presentations work", {
  expect_equal(1, 1)
})

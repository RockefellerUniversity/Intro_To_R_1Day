library(testthat)
library(introToR)

test_check("introToR")
